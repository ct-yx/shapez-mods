# shapez.io Mods Collection — 安装说明

1. 将 `mods/` 中需要启用的 `.js` 文件复制到 shapez.io 的 Mod 目录。
2. macOS 常用目录：`~/Library/Preferences/shapez.io/mods/`
3. 重启游戏后，在 Mod 管理界面启用对应 Mod。
4. 想配置带设置项的 Mod 时，同时启用 `structured-mod-settings.js`，然后打开「设置 → 游戏模组（MODS）」。

完整文档与截图：https://ct-yx.github.io/shapez-mods/
